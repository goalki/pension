package pension.dto;

public class MemberDto {
   private int id,state;
   private String name,userid,pwd,phone,writeday;
   
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getState() {
	return state;
}
public void setState(int state) {
	this.state = state;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getUserid() {
	return userid;
}
public void setUserid(String userid) {
	this.userid = userid;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getWriteday() {
	return writeday;
}
public void setWriteday(String writeday) {
	this.writeday = writeday;
}
   
   
}
