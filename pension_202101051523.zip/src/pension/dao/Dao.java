package pension.dao;

import java.sql.*;
import java.util.ArrayList;

import pension.dto.RoomDto;

public class Dao {

	String db="jdbc:mysql://localhost:3306/pension"; 
	String userid="root";
    String pw="1234";
    Connection conn;
	public Dao() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver"); // 기능은 무조건 메소드내에서 실행
		conn=DriverManager.getConnection(db,userid,pw);
	}
	
    public ArrayList<RoomDto> get_room() throws SQLException
    {
    	String sql="select name,id from room order by price asc";
    	Statement stmt=conn.createStatement();
    	ResultSet rs=stmt.executeQuery(sql);
    	ArrayList<RoomDto> list=new ArrayList<RoomDto>();
    	while(rs.next())
    	{
    		RoomDto rdto=new RoomDto();
    		rdto.setId(rs.getInt("id"));
    		rdto.setName(rs.getString("name"));
    		list.add(rdto);
    	}
    	/*
    	String sql="select name from room order by price asc";
    	Statement stmt=conn.createStatement();
    	ResultSet rs=stmt.executeQuery(sql);
    	ArrayList<String> list=new ArrayList<String>();
    	while(rs.next())
    	{
    		list.add(rs.getString("name"));
    	}
    	*/
    	return list;
    }
}







