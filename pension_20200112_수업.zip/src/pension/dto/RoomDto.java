package pension.dto;

public class RoomDto {
   private int id,max,min,price;
   private String name;
   
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public int getMax() {
	return max;
}
public void setMax(int max) {
	this.max = max;
}
public int getMin() {
	return min;
}
public void setMin(int min) {
	this.min = min;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
   
   // private인 필드에 외부에서 접근 => getter,setter
   
}
