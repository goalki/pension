package pension.dao;

import java.sql.*;
import java.util.ArrayList;

import pension.dto.ReserveDto;
import pension.dto.RoomDto;

public class Dao {

	String db="jdbc:mysql://localhost:3306/pension"; 
	String userid="root";
    String pw="1234";
    Connection conn;
	public Dao() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver"); // 기능은 무조건 메소드내에서 실행
		conn=DriverManager.getConnection(db,userid,pw);
	}
	// room 테이블의 전체내용을 가져오기
    public ArrayList<RoomDto> get_room() throws SQLException
    {
    	String sql="select name,id from room order by price asc";
    	Statement stmt=conn.createStatement();
    	ResultSet rs=stmt.executeQuery(sql);
    	ArrayList<RoomDto> list=new ArrayList<RoomDto>();
    	while(rs.next())
    	{
    		RoomDto rdto=new RoomDto();
    		rdto.setId(rs.getInt("id"));
    		rdto.setName(rs.getString("name"));
    		list.add(rdto);
    	}
    	/*
    	String sql="select name from room order by price asc";
    	Statement stmt=conn.createStatement();
    	ResultSet rs=stmt.executeQuery(sql);
    	ArrayList<String> list=new ArrayList<String>();
    	while(rs.next())
    	{
    		list.add(rs.getString("name"));
    	}
    	*/
    	return list;
    }
    
    // 사용자가 선택한 방의 정보를 가져오기
    public RoomDto select_room(String id) throws SQLException
    {
    	String sql="select * from room where id="+id;
    	Statement stmt=conn.createStatement();
    	ResultSet rs=stmt.executeQuery(sql);
    	rs.next();
    	RoomDto rdto=new RoomDto();
    	rdto.setId(rs.getInt("id"));
    	rdto.setName(rs.getString("name"));
    	rdto.setMax(rs.getInt("max"));
    	rdto.setMin(rs.getInt("min"));
    	rdto.setPrice(rs.getInt("price"));
    	
    	return rdto;
    }
    
    public void insert(ReserveDto rdto) throws SQLException // reserve테이블에 입력값을 넣기
    {
    	// 쿼리 생성
    	String outday="date_add('"+rdto.getInday()+"', interval "+rdto.getSuk()+" day)";
    	String sql="insert into reserve(rid,name,phone,inday,outday";
    	sql=sql+",inwon1,inwon2,inwon3,bbq,pork,suk_price,etc_price,tot_price,writeday) ";
    	sql=sql+" values(?,?,?,?,"+outday+",?,?,?,?,?,?,?,?,now())";
    	
    	// date_add('2021-01-05',interval 숙박일 day);
    	PreparedStatement pstmt=conn.prepareStatement(sql);
    	pstmt.setInt(1, rdto.getRid());
    	pstmt.setString(2, rdto.getName());
    	pstmt.setString(3, rdto.getPhone());
    	pstmt.setString(4, rdto.getInday());
    	//pstmt.setString(5, outday);
    	pstmt.setInt(5, rdto.getInwon1());
    	pstmt.setInt(6, rdto.getInwon2());
    	pstmt.setInt(7, rdto.getInwon3());
    	pstmt.setInt(8, rdto.getBbq());
    	pstmt.setInt(9, rdto.getPork());
    	pstmt.setInt(10, rdto.getSuk_price());
    	pstmt.setInt(11, rdto.getEtc_price());
    	pstmt.setInt(12, rdto.getTot_price());
    	
    	pstmt.executeUpdate();
    	//System.out.println(pstmt.toString());
    	conn.close();
    }
    
    public ReserveDto get_reserve(String phone) throws SQLException // 방금 예약한 정보를 가져오는 메소드(1개의 레코드)
    {
    	String sql="select * from reserve where phone='"+phone+"' order by id desc limit 1";
    	Statement stmt=conn.createStatement();
    	ResultSet rs=stmt.executeQuery(sql);
    	rs.next();
    	ReserveDto rdto=new ReserveDto();
    	rdto.setId(rs.getInt("id"));
    	rdto.setRid(rs.getInt("rid"));
    	rdto.setName(rs.getString("name"));
    	rdto.setPhone(rs.getString("phone"));
    	rdto.setInday(rs.getString("inday"));
    	rdto.setOutday(rs.getString("outday"));
    	rdto.setInwon1(rs.getInt("inwon1"));
    	rdto.setInwon2(rs.getInt("inwon2"));
    	rdto.setInwon3(rs.getInt("inwon3"));
    	rdto.setBbq(rs.getInt("bbq"));
    	rdto.setPork(rs.getInt("pork"));
    	rdto.setSuk_price(rs.getInt("suk_price"));
    	rdto.setEtc_price(rs.getInt("etc_price"));
    	rdto.setTot_price(rs.getInt("tot_price"));
    	rdto.setWriteday(rs.getString("writeday"));
    	
    	// 방이름 가져오기 
    	sql="select name from room where id="+rdto.getRid();
    	rs=stmt.executeQuery(sql);
    	rs.next();
    	rdto.setRoomname(rs.getString("name"));
    	return rdto;
    	
    }
}







